﻿//This file create a set of 5 backups each containing a journal for producing 12 records
//This sample data set is to be used to test integration

var items=new Array();
var itemSequenceLength = 10
items[0]="-- Start "+itemSequenceLength+" item(s)--";
for(var k=1;k<=itemSequenceLength;k++){
	items[k]="Data item "+k;
}
items[items.length]="-- End "+itemSequenceLength+" item(s)";

function createRecordSet(itemArray)
{
	for(var i=0;i<itemArray.length;i++){
		var e = new ds.DataClass1({"field1":itemArray[i]});
		e.save();
	}
	ds.backup();
}

for(var j=0;j<5;j++)
{
	createRecordSet(items);
	var t0 = new Date().getTime();
	var t1 = t0;
	while((t1 >= t0) && (t1-t0<1000)){
		t1 = new Date().getTime();
	}
}
